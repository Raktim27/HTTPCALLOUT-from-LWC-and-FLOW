import { LightningElement, api } from 'lwc';

export default class ZipCodeResultComponent extends LightningElement {
    @api result;
}